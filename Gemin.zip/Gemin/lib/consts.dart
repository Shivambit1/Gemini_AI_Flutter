const String GEMINI_API_KEY = "AIzaSyBwd6omSF_CohqdVFHV_LlgOHpFhRJRNNo";
